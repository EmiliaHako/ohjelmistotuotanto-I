﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mokkiprojekti
{
    internal class Alue
    {
        public int alue_id { get; set; }
        public string nimi { get; set; }
    }
}
