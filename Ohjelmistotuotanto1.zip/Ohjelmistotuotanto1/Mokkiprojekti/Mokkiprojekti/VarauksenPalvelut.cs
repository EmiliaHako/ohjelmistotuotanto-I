﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mokkiprojekti
{
    internal class VarauksenPalvelut
    {
        public int varaus_id { get; set; }
        public int palvelu_id { get; set; }
        public int lkm { get; set; }
    }
}
